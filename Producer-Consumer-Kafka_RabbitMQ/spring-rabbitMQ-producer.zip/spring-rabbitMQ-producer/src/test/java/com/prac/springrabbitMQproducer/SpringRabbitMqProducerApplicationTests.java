package com.prac.springrabbitMQproducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRabbitMqProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
