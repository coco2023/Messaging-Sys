package com.prac.springrabbitMQconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRabbitMqConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRabbitMqConsumerApplication.class, args);
	}

}
