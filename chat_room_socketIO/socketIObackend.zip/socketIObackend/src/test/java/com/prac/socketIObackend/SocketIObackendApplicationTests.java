package com.prac.socketIObackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocketIObackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
