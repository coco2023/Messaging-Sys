package com.prac.springkafkamessaging;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringKafkaMessagingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringKafkaMessagingApplication.class, args);
	}

}
